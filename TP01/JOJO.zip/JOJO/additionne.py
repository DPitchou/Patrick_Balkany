import sys

print(float(sys.argv[1]) + float(sys.argv[2]))