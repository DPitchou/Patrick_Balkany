
import sys

print(float(sys.argv[1]) ** 2)