from Module import *
from Ressources import L1, L2, L3

print("Trajet 1:--------------------------")
print("Distance:", SommeDistance(L1), "m")
print("Durée: ", SommeDuree(L1), "min")
print("Vitesse:", SommeDistance(L1) / SommeDuree(L1), "m/min")
print("Trajet 2:--------------------------")
print("Distance:", SommeDistance(L2), "m")
print("Durée: ", SommeDuree(L2), "min")
print("Vitesse:", SommeDistance(L2) / SommeDuree(L2), "m/min")
print("Trajet 3:--------------------------")
print("Distance:", SommeDistance(L3), "m")
print("Durée: ", SommeDuree(L3), "min")
print("Vitesse:", SommeDistance(L3) / SommeDuree(L3), "m/min")